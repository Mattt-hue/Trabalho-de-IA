# INF1771 – Trabalho 1: Busca Heurística (Pokémon / Kanto)

## Como rodar
```
pip install numpy matplotlib pillow
python main.py                    # tudo + certificado de otimalidade da rota (~1-2 min, ~0,8 GB RAM)
python main.py --execucoes 30     # experimento HC/SA/GA com 30 execuções cada
python main.py --sem-certificado  # só o A* ponderado (segundos)
python main.py --visual           # gera resultado.png e resultado.gif
python main.py --ascii            # mapa no console
```
Arquivos: `config.py` (custos de terreno, dificuldades, poderes, energia), `mapa.txt` (mapa 42x150,
editável), `mapa.py`, `rota.py` (A*), `batalhas.py` (busca local), `visual.py`, `main.py`.

## Tarefa 1 – Batalhas (busca local)
* **Representação:** 24 máscaras de bits (1..31); bit p = Pokémon p luta naquele ginásio.
* **Custo:** Σ dificuldade_i / Σ poder + 100 · (violações de energia). Restrições: cada Pokémon luta ≤ 6 vezes
  e pelo menos um luta ≤ 5 vezes (chega com energia ≥ 1). A penalidade (100) é maior que o maior ganho
  possível de um uso extra (~58 min), então o ótimo penalizado é viável.
* **Vizinhança:** alternar Pokémon, substituir Pokémon, transferir Pokémon entre ginásios, trocar equipes entre ginásios.
* **Algoritmos:** Hill Climbing (ascensão máxima + 20 reinícios), Simulated Annealing, Algoritmo Genético.
* **Referência exata:** DP sobre (ginásio, uso dos 5 Pokémon) – 7^5 estados – prova o ótimo global das batalhas.

## Tarefa 2 – Rota (A*)
* **Estado:** (ponto atual, conjunto de ginásios visitados) – o conjunto é uma máscara de 24 bits.
* **Ações:** ir pelo caminho mínimo da grade até um ginásio não visitado; com todos visitados, ir a U.
* **Custo:** 1 (origem) + soma do custo de terreno de cada célula entrada (M=200, A=30, F=15, R=5, .=1).
  Pernas calculadas na grade 4-conexa; o A* célula a célula (h = Manhattan × menor custo) é usado na visualização.
* **Heurística:** h = menor aresta do ponto atual a um ginásio livre + MST dos ginásios livres + menor aresta de um
  ginásio livre ao destino. Admissível e consistente.
* **Otimalidade:** com peso 1 o A* é ótimo, mas em Python não termina para 24 ginásios (>600 mil expansões, sem fim).
  Por isso: A* ponderado (peso 2) dá solução rápida (custo 1275, 438 expansões) e a **otimalidade é certificada
  por Held-Karp exato** (custo 1210).

## Independência dos problemas
O tempo de um ginásio depende só da dificuldade e dos Pokémon escolhidos, não da ordem de visita.
Logo C_total ótimo = rota ótima + batalhas ótimas.
